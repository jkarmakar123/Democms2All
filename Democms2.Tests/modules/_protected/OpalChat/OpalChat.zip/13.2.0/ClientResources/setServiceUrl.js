﻿(function() {
    const optiOpalContextRoot = document.getElementsByTagName(
        "opti-opalchat-context",
    )[0];

    const serviceUrl =
        optiOpalContextRoot?.getAttribute("serviceUrl")?.trim() ??
        "";
    const appBaseUrl =
        optiOpalContextRoot?.getAttribute("appBaseUrl")?.trim() ??
        "";

    const socketUrl =
        optiOpalContextRoot?.getAttribute("socketUrl")?.trim() ??
        "";

    if (!serviceUrl || !appBaseUrl || !socketUrl) {
        console.error("Opal Chat configuration incomplete", {
            hasServiceUrl: !!serviceUrl,
            hasAppBaseUrl: !!appBaseUrl,
            hasSocketUrl: !!socketUrl
        });
        return false;
    }

    try {
        localStorage.setItem("ai-chat:BASE_URL",
            serviceUrl);
        localStorage.setItem("ai-chat:OPAL_APP_BASE_URL",
            appBaseUrl);
        localStorage.setItem("ai-chat:SOCKET_URL",
            socketUrl);

        return true;
    } catch (error) {
        console.error("Failed to initialize Opal Chat:",
            error);
        return false;
    }
})();

